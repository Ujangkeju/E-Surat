<?php
require_once __DIR__ . "/../includes/auth.php";
require_once __DIR__ . "/../config/koneksi.php";

if ($_SESSION['role'] != 'mahasiswa') {
    header("Location: ../login.php");
    exit;
}

require_once __DIR__ . "/../includes/header.php";
require_once __DIR__ . "/../includes/sidebar.php";

// Ambil data mahasiswa berdasarkan user yang login
$user = $_SESSION['id_user'];

$dataMhs = mysqli_query($conn, "
SELECT *
FROM mahasiswa
WHERE id_user='$user'
");

$mhs = mysqli_fetch_assoc($dataMhs);

$id_mahasiswa = $mhs['id_mahasiswa'];

// Total Pengajuan
$q1 = mysqli_query($conn, "
SELECT COUNT(*) AS total
FROM pengajuan_surat
WHERE id_mahasiswa='$id_mahasiswa'
");
$totalPengajuan = mysqli_fetch_assoc($q1)['total'];

// Menunggu
$q2 = mysqli_query($conn, "
SELECT COUNT(*) AS total
FROM pengajuan_surat
WHERE id_mahasiswa='$id_mahasiswa'
AND status='Menunggu'
");
$totalMenunggu = mysqli_fetch_assoc($q2)['total'];

// Diproses
$q3 = mysqli_query($conn, "
SELECT COUNT(*) AS total
FROM pengajuan_surat
WHERE id_mahasiswa='$id_mahasiswa'
AND status='Diproses'
");
$totalDiproses = mysqli_fetch_assoc($q3)['total'];

// Selesai
$q4 = mysqli_query($conn, "
SELECT COUNT(*) AS total
FROM pengajuan_surat
WHERE id_mahasiswa='$id_mahasiswa'
AND status='Selesai'
");
$totalSelesai = mysqli_fetch_assoc($q4)['total'];

?>

<div class="container-fluid">

    <div class="mb-4">

        <h3 class="fw-bold">

            Dashboard Mahasiswa

        </h3>

        <p class="text-muted">

            Selamat datang,

            <b><?= $mhs['nama']; ?></b>

        </p>

    </div>

    <div class="row">

        <div class="col-lg-3 col-md-6 mb-4">

            <div class="card shadow-sm border-0">

                <div class="card-body">

                    <div class="d-flex justify-content-between">

                        <div>

                            <small class="text-muted">

                                Total Pengajuan

                            </small>

                            <h2 class="fw-bold mt-2">

                                <?= $totalPengajuan; ?>

                            </h2>

                        </div>

                        <div class="fs-1 text-primary">

                            <i class="bi bi-envelope-paper-fill"></i>

                        </div>

                    </div>

                </div>

            </div>

        </div>

        <div class="col-lg-3 col-md-6 mb-4">

            <div class="card shadow-sm border-0">

                <div class="card-body">

                    <div class="d-flex justify-content-between">

                        <div>

                            <small class="text-muted">

                                Menunggu

                            </small>

                            <h2 class="fw-bold mt-2">

                                <?= $totalMenunggu; ?>

                            </h2>

                        </div>

                        <div class="fs-1 text-secondary">

                            <i class="bi bi-hourglass-split"></i>

                        </div>

                    </div>

                </div>

            </div>

        </div>

        <div class="col-lg-3 col-md-6 mb-4">

            <div class="card shadow-sm border-0">

                <div class="card-body">

                    <div class="d-flex justify-content-between">

                        <div>

                            <small class="text-muted">

                                Diproses

                            </small>

                            <h2 class="fw-bold mt-2">

                                <?= $totalDiproses; ?>

                            </h2>

                        </div>

                        <div class="fs-1 text-warning">

                            <i class="bi bi-arrow-repeat"></i>

                        </div>

                    </div>

                </div>

            </div>

        </div>

        <div class="col-lg-3 col-md-6 mb-4">

            <div class="card shadow-sm border-0">

                <div class="card-body">

                    <div class="d-flex justify-content-between">

                        <div>

                            <small class="text-muted">

                                Selesai

                            </small>

                            <h2 class="fw-bold mt-2">

                                <?= $totalSelesai; ?>

                            </h2>

                        </div>

                        <div class="fs-1 text-success">

                            <i class="bi bi-check-circle-fill"></i>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

    <div class="row">

        <div class="col-lg-8">

            <div class="card shadow-sm border-0">

                <div class="card-header bg-white">

                    <h5 class="mb-0">

                        Riwayat Pengajuan Terbaru

                    </h5>

                </div>

                <div class="card-body">

                    <div class="table-responsive">

                        <table class="table table-hover align-middle">

                            <thead class="table-primary">

                                <tr>

                                    <th>No</th>

                                    <th>Jenis Surat</th>

                                    <th>Tanggal</th>

                                    <th>Status</th>

                                </tr>

                            </thead>

                            <tbody>

                                <?php

                                $no = 1;

                                $riwayat = mysqli_query($conn, "

SELECT

pengajuan_surat.*,

jenis_surat.nama_surat

FROM pengajuan_surat

JOIN jenis_surat
ON pengajuan_surat.id_jenis=jenis_surat.id_jenis

WHERE id_mahasiswa='$id_mahasiswa'

ORDER BY id_pengajuan DESC

LIMIT 5

");

                                if (mysqli_num_rows($riwayat) > 0) {

                                    while ($r = mysqli_fetch_assoc($riwayat)) {

                                ?>

                                        <tr>

                                            <td><?= $no++; ?></td>

                                            <td><?= $r['nama_surat']; ?></td>

                                            <td><?= date('d-m-Y', strtotime($r['tanggal_pengajuan'])); ?></td>

                                            <td>

                                                <?php

                                                if ($r['status'] == "Menunggu") {

                                                    echo "<span class='badge bg-secondary'>Menunggu</span>";
                                                } elseif ($r['status'] == "Diproses") {

                                                    echo "<span class='badge bg-warning text-dark'>Diproses</span>";
                                                } elseif ($r['status'] == "Selesai") {

                                                    echo "<span class='badge bg-success'>Selesai</span>";
                                                } else {

                                                    echo "<span class='badge bg-danger'>Ditolak</span>";
                                                }

                                                ?>

                                            </td>

                                        </tr>

                                <?php

                                    }
                                } else {

                                    echo "

<tr>

<td colspan='4' class='text-center'>

Belum ada pengajuan surat.

</td>

</tr>

";
                                }

                                ?>

                            </tbody>

                        </table>

                    </div>

                </div>

            </div>

        </div>

        <div class="col-lg-4">

            <div class="card shadow-sm border-0">

                <div class="card-header bg-white">

                    <h5 class="mb-0">

                        Menu Cepat

                    </h5>

                </div>

                <div class="card-body d-grid gap-3">

                    <a
                        href="pengajuan.php"
                        class="btn btn-primary">

                        <i class="bi bi-file-earmark-plus-fill"></i>

                        Ajukan Surat

                    </a>

                    <a
                        href="status.php"
                        class="btn btn-success">

                        <i class="bi bi-clock-history"></i>

                        Lihat Status Surat

                    </a>

                </div>

            </div>

            <div class="card shadow-sm border-0 mt-4">

                <div class="card-body">

                    <h6 class="fw-bold">

                        Informasi Mahasiswa

                    </h6>

                    <hr>

                    <p class="mb-2">

                        <b>NIM :</b><br>

                        <?= $mhs['nim']; ?>

                    </p>

                    <p class="mb-2">

                        <b>Nama :</b><br>

                        <?= $mhs['nama']; ?>

                    </p>

                    <p class="mb-0">

                        <b>Program Studi :</b><br>

                        <?= $mhs['prodi']; ?>

                    </p>

                </div>

            </div>

        </div>

    </div>

</div>

<?php
require_once __DIR__ . "/../includes/footer.php";
?>