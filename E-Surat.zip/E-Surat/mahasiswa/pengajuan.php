<?php
require_once __DIR__ . "/../includes/auth.php";
require_once __DIR__ . "/../config/koneksi.php";

if ($_SESSION['role'] != 'mahasiswa') {
    header("Location: ../login.php");
    exit;
}

require_once __DIR__ . "/../includes/header.php";
require_once __DIR__ . "/../includes/sidebar.php";

// Ambil data mahasiswa
$id_user = $_SESSION['id_user'];

$data = mysqli_query($conn, "
SELECT *
FROM mahasiswa
WHERE id_user='$id_user'
");

$mhs = mysqli_fetch_assoc($data);

$id_mahasiswa = $mhs['id_mahasiswa'];

/* ===========================
   SIMPAN PENGAJUAN
=========================== */

if (isset($_POST['simpan'])) {

    $id_jenis = $_POST['id_jenis'];
    $keperluan = htmlspecialchars($_POST['keperluan']);

    mysqli_query($conn, "
    INSERT INTO pengajuan_surat
    (
        id_mahasiswa,
        id_jenis,
        keperluan,
        tanggal_pengajuan,
        status
    )
    VALUES
    (
        '$id_mahasiswa',
        '$id_jenis',
        '$keperluan',
        CURDATE(),
        'Menunggu'
    )
    ");

    echo "<script>

    alert('Pengajuan surat berhasil dikirim.');

    window.location='status.php';

    </script>";
}

?>

<div class="container-fluid">

    <div class="row justify-content-center">

        <div class="col-lg-8">

            <div class="card shadow-sm border-0">

                <div class="card-header bg-primary text-white">

                    <h4 class="mb-0">

                        <i class="bi bi-file-earmark-plus-fill"></i>

                        Ajukan Surat

                    </h4>

                </div>

                <div class="card-body">

                    <form method="POST">

                        <div class="mb-3">

                            <label class="form-label">

                                NIM

                            </label>

                            <input

                                type="text"

                                class="form-control"

                                value="<?= $mhs['nim']; ?>"

                                readonly disabled>

                        </div>

                        <div class="mb-3">

                            <label class="form-label">

                                Nama Mahasiswa

                            </label>

                            <input

                                type="text"

                                class="form-control"

                                value="<?= $mhs['nama']; ?>"

                                readonly disabled>

                        </div>

                        <div class="mb-3">

                            <label class="form-label">

                                Program Studi

                            </label>

                            <input

                                type="text"

                                class="form-control"

                                value="<?= $mhs['prodi']; ?>"

                                readonly disabled>

                        </div>

                        <div class="mb-3">

                            <label class="form-label">

                                Jenis Surat

                            </label>

                            <select

                                name="id_jenis"

                                class="form-select"

                                required>

                                <option value="">

                                    -- Pilih Jenis Surat --

                                </option>

                                <?php

                                $jenis = mysqli_query($conn, "
SELECT *
FROM jenis_surat
ORDER BY nama_surat ASC
");

                                while ($j = mysqli_fetch_assoc($jenis)) {

                                ?>

                                    <option value="<?= $j['id_jenis']; ?>">

                                        <?= $j['nama_surat']; ?>

                                    </option>

                                <?php } ?>

                            </select>

                        </div>

                        <div class="mb-3">

                            <label class="form-label">

                                Keperluan

                            </label>

                            <textarea

                                name="keperluan"

                                rows="5"

                                class="form-control"

                                placeholder="Contoh : Digunakan untuk keperluan beasiswa..."

                                required>

</textarea>

                        </div>

                        <div class="d-flex justify-content-end gap-2">

                            <a

                                href="dashboard.php"

                                class="btn btn-secondary">

                                <i class="bi bi-arrow-left"></i>

                                Kembali

                            </a>

                            <button

                                type="submit"

                                name="simpan"

                                class="btn btn-primary">

                                <i class="bi bi-send-fill"></i>

                                Kirim Pengajuan

                            </button>

                        </div>

                    </form>

                </div>

            </div>

            <div class="card shadow-sm border-0 mt-4">

                <div class="card-body">

                    <h5 class="fw-bold">

                        Informasi

                    </h5>

                    <hr>

                    <ul class="mb-0">

                        <li>
                            Pastikan memilih jenis surat yang benar.
                        </li>

                        <li>
                            Isi keperluan dengan jelas.
                        </li>

                        <li>
                            Setelah dikirim, pengajuan akan diperiksa oleh Tata Usaha.
                        </li>

                        <li>
                            Status pengajuan dapat dilihat pada menu <b>Status Surat</b>.
                        </li>

                    </ul>

                </div>

            </div>

        </div>

    </div>

</div>

<?php
require_once __DIR__ . "/../includes/footer.php";
?>