<?php
require_once __DIR__ . "/../includes/auth.php";
require_once __DIR__ . "/../config/koneksi.php";

if ($_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

require_once __DIR__ . "/../includes/header.php";
require_once __DIR__ . "/../includes/sidebar.php";

// Total Mahasiswa
$qMahasiswa = mysqli_query($conn, "SELECT COUNT(*) AS total FROM mahasiswa");
$totalMahasiswa = mysqli_fetch_assoc($qMahasiswa)['total'];

// Total Jenis Surat
$qJenis = mysqli_query($conn, "SELECT COUNT(*) AS total FROM jenis_surat");
$totalJenis = mysqli_fetch_assoc($qJenis)['total'];

// Total Pengajuan
$qPengajuan = mysqli_query($conn, "SELECT COUNT(*) AS total FROM pengajuan_surat");
$totalPengajuan = mysqli_fetch_assoc($qPengajuan)['total'];

// Surat Selesai
$qSelesai = mysqli_query($conn, "SELECT COUNT(*) AS total FROM pengajuan_surat WHERE status='Selesai'");
$totalSelesai = mysqli_fetch_assoc($qSelesai)['total'];
?>

<div class="container-fluid">

    <div class="mb-4">
        <h3 class="fw-bold">Dashboard Admin</h3>
        <p class="text-muted">
            Selamat Datang,
            <b><?= $_SESSION['username']; ?></b>
        </p>
    </div>

    <div class="row">

        <div class="col-lg-3 col-md-6 mb-4">
            <div class="card shadow-sm border-0">
                <div class="card-body">

                    <div class="d-flex justify-content-between">

                        <div>

                            <small class="text-muted">
                                Total Mahasiswa
                            </small>

                            <h2 class="fw-bold mt-2">
                                <?= $totalMahasiswa; ?>
                            </h2>

                        </div>

                        <div class="fs-1 text-primary">

                            <i class="bi bi-people-fill"></i>

                        </div>

                    </div>

                </div>
            </div>
        </div>

        <div class="col-lg-3 col-md-6 mb-4">
            <div class="card shadow-sm border-0">
                <div class="card-body">

                    <div class="d-flex justify-content-between">

                        <div>

                            <small class="text-muted">
                                Jenis Surat
                            </small>

                            <h2 class="fw-bold mt-2">
                                <?= $totalJenis; ?>
                            </h2>

                        </div>

                        <div class="fs-1 text-success">

                            <i class="bi bi-file-earmark-text-fill"></i>

                        </div>

                    </div>

                </div>
            </div>
        </div>

        <div class="col-lg-3 col-md-6 mb-4">
            <div class="card shadow-sm border-0">
                <div class="card-body">

                    <div class="d-flex justify-content-between">

                        <div>

                            <small class="text-muted">
                                Pengajuan Surat
                            </small>

                            <h2 class="fw-bold mt-2">
                                <?= $totalPengajuan; ?>
                            </h2>

                        </div>

                        <div class="fs-1 text-warning">

                            <i class="bi bi-envelope-paper-fill"></i>

                        </div>

                    </div>

                </div>
            </div>
        </div>

        <div class="col-lg-3 col-md-6 mb-4">
            <div class="card shadow-sm border-0">
                <div class="card-body">

                    <div class="d-flex justify-content-between">

                        <div>

                            <small class="text-muted">
                                Surat Selesai
                            </small>

                            <h2 class="fw-bold mt-2">
                                <?= $totalSelesai; ?>
                            </h2>

                        </div>

                        <div class="fs-1 text-danger">

                            <i class="bi bi-check-circle-fill"></i>

                        </div>

                    </div>

                </div>
            </div>
        </div>

    </div>

    <div class="row">

        <div class="col-lg-8 mb-4">

            <div class="card shadow-sm border-0">

                <div class="card-header bg-white">

                    <h5 class="mb-0">
                        Pengajuan Surat Terbaru
                    </h5>

                </div>

                <div class="card-body">

                    <div class="table-responsive">

                        <table class="table table-hover align-middle">

                            <thead class="table-primary">

                                <tr>

                                    <th>No</th>

                                    <th>Nama Mahasiswa</th>

                                    <th>Jenis Surat</th>

                                    <th>Status</th>

                                </tr>

                            </thead>

                            <tbody>

                                <?php

                                $no = 1;

                                $sql = mysqli_query($conn, "
                                    SELECT
                                    mahasiswa.nama,
                                    jenis_surat.nama_surat,
                                    pengajuan_surat.status
                                    FROM pengajuan_surat
                                    JOIN mahasiswa
                                    ON pengajuan_surat.id_mahasiswa=mahasiswa.id_mahasiswa
                                    JOIN jenis_surat
                                    ON pengajuan_surat.id_jenis=jenis_surat.id_jenis
                                    ORDER BY id_pengajuan DESC
                                    LIMIT 5
                                ");

                                if (mysqli_num_rows($sql) > 0) {

                                    while ($d = mysqli_fetch_assoc($sql)) {

                                ?>

                                        <tr>

                                            <td><?= $no++; ?></td>

                                            <td><?= $d['nama']; ?></td>

                                            <td><?= $d['nama_surat']; ?></td>

                                            <td>

                                                <?php

                                                if ($d['status'] == "Menunggu") {

                                                    echo "<span class='badge bg-secondary'>Menunggu</span>";
                                                } elseif ($d['status'] == "Diproses") {

                                                    echo "<span class='badge bg-warning text-dark'>Diproses</span>";
                                                } elseif ($d['status'] == "Selesai") {

                                                    echo "<span class='badge bg-success'>Selesai</span>";
                                                } elseif ($d['status'] == "Ditolak") {

                                                    echo "<span class='badge bg-danger'>Ditolak</span>";
                                                }

                                                ?>

                                            </td>

                                        </tr>

                                <?php

                                    }
                                } else {

                                    echo "<tr><td colspan='4' class='text-center'>Belum ada data.</td></tr>";
                                }

                                ?>

                            </tbody>

                        </table>

                    </div>

                </div>

            </div>

        </div>

        <div class="col-lg-4">

            <div class="card shadow-sm border-0">

                <div class="card-header bg-white">

                    <h5 class="mb-0">
                        Menu Cepat
                    </h5>

                </div>

                <div class="card-body d-grid gap-3">

                    <a href="mahasiswa.php" class="btn btn-primary">

                        <i class="bi bi-people-fill"></i>

                        Data Mahasiswa

                    </a>

                    <a href="jenis_surat.php" class="btn btn-success">

                        <i class="bi bi-file-earmark-text-fill"></i>

                        Jenis Surat

                    </a>

                </div>

            </div>

        </div>

    </div>

</div>

<?php
include "../includes/footer.php";
?>